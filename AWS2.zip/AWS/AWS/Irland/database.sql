CREATE TABLE cloudraiser (
    id BIGINT PRIMARY KEY,
    body VARCHAR(255)
);