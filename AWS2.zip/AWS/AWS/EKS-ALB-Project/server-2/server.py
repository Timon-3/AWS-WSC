from flask import Flask
import requests
import os

app = Flask(__name__)

@app.route('/')
def index():
    metadata = {
        "namespace": os.getenv('POD_NAMESPACE'),
        "name": os.getenv('POD_NAME'),
        "node_name": os.getenv('NODE_NAME'),
        "pod_ip": os.getenv('POD_IP')
    }

    metadata_html = "<html><body><h1>Pod Metadata</h1><ul>"
    for key, value in metadata.items():
        metadata_html += f"<li>{key}: {value}</li>"
    metadata_html += "</ul></body></html>"

    return metadata_html

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)
