#!/bin/sh

# Fetch metadata
SERVER_NAME=$(curl -s http://169.254.169.254/latest/meta-data/hostname)
IP_ADDRESS=$(curl -s http://169.254.169.254/latest/meta-data/local-ipv4)
AVAILABILITY_ZONE=$(curl -s http://169.254.169.254/latest/meta-data/placement/availability-zone)
SUBNET_ID=$(curl -s http://169.254.169.254/latest/meta-data/network/interfaces/macs/$(curl -s http://169.254.169.254/latest/meta-data/mac)/subnet-id)

# Create an HTML file to display the metadata
cat <<EOF > /usr/share/nginx/html/index.html
<!DOCTYPE html>
<html>
<head>
    <title>Instance Metadata</title>
</head>
<body>
    <h1>Instance Metadata</h1>
    <p><strong>Server Name:</strong> ${SERVER_NAME}</p>
    <p><strong>IP Address:</strong> ${IP_ADDRESS}</p>
    <p><strong>Availability Zone:</strong> ${AVAILABILITY_ZONE}</p>
    <p><strong>Subnet ID:</strong> ${SUBNET_ID}</p>
</body>
</html>
EOF
